/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.h
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __AddFuntion_H_
#define __AddFuntion_H_

/* Exported types -------------------------------------------------------------------------------*/
typedef struct
{
//voltage protect
      uint16 		 OverVoltDetecCnt;     // 过压检测计数
      uint16 		 UnderVoltDetecCnt;    // 欠压检测计数



//OVER Current protect recover
	  uint16 		OverCurrentCnt;       // 过流检测计数
	  uint16 		OverCurrentCnt1;      // 过流检测计数
	  uint16 		OverCurrentCnt2;      // 过流检测计数
	  uint16 		OC_Recover_CNT;       // 过流恢复计数
	
//stall protect
      uint16     	StallPWMCnt;        // 堵转延迟判断计时	
	    uint16     	Stall_Recover_CNT;  //堵转恢复计数
	
//Temper protect
	  uint16       MosTemperCnt;         // Mos温度判断计数
	  uint16       MosTemperRecover;     // Mos温度恢复判断计数
	  uint16	     BatTemperCnt;         // Bat温度判断计数
	  uint16       BatTemperRecover;     // Bat温度恢复判断计数
		
}FaultVarible;

typedef enum
{
	  FaultNoSource				 = 0,        // 无故障
      FaultSoftOVCurrent         = 1,        // 一级过流保护
      FaultSoftOVCurrent1        = 2,        // 二级过流保护
      FaultSoftOVCurrent2        = 3,        // 三级过流保护
	  FaultHardOVCurrent         = 4,	     // 硬件过流
      FaultUnderVoltage	         = 5,	     // 欠压保护
      FaultOverVoltage           = 6,        // 过压保护
	  FaultMosOverTemperature    = 7,        // Mos过温保护
	  FaultBatOverTemperature    = 8,        // Bat过温保护	
	  FaultLossPhase   		     = 9,        // 缺相保护
	  FaultStall 			     = 10,       // 堵转保护 
      FaultLostStep              = 11,       // 失步保护        
      FaultLVW                   = 12,       // LVW保护     
	   FaultAntiFlying                  = 13,   
      FaultVSPInvalid            = 14,     //线性hall 调速启停开关电压值偏离正常范围
} FaultStateType;


/*
 * VSP偏置状态机：
 * 1. 上电只采一次释放态偏置，偏置合法后进入READY。
 * 2. READY状态只做启停迟滞和速度映射，不再重新采偏置。
 * 3. 偏置非法后进入故障提示流程，三声报警后等待6S，再用独立恢复采样变量重新判断。
 */
typedef enum
{
      VSP_STATE_INIT_STABLE      = 0,      // 上电后等待VSP滤波值稳定
      VSP_STATE_INIT_SAMPLE      = 1,      // 上电主偏置采样
      VSP_STATE_READY            = 2,      // 偏置合法，正常启停和调速
      VSP_STATE_FAULT_BEEP       = 3,      // VSP非法，先响3声
      VSP_STATE_FAULT_WAIT       = 4,      // 响完后等待6S
      VSP_STATE_FAULT_SAMPLE     = 5,      // 6S后重新采样判断恢复
} VSPStateType;


typedef struct
{
      uint16       Offset;                  // 已采到的释放态偏置
      uint16       OnDuty;                  // 启动阈值：Offset + 0.20V
      uint16       OffDuty;                 // 停止阈值：Offset + 0.07V
      uint16       MinDuty;                 // 速度曲线最小转速点
      VSPStateType State;                   // VSP偏置/故障恢复状态机
      uint32       InitOffsetSum;           // 上电偏置采样累加值，仅INIT_SAMPLE使用
      uint32       RecoverOffsetSum;        // 故障恢复采样累加值，仅FAULT_SAMPLE使用
      uint16       InitStableCnt;           // 上电后等待VSP滤波稳定计数
      uint16       FaultWaitCnt;            // VSP非法报警后6S恢复等待计数
      uint8        InitOffsetCnt;           // 上电偏置采样次数
      uint8        RecoverOffsetCnt;        // 故障恢复采样次数
      uint8        OffsetReady;             // 偏置合法并已生成启停阈值
      uint8        BeepStarted;             // VSP三声报警已触发标志，防止重复启动蜂鸣
} VSPCtrlTypeDef;


typedef struct
{
    uint16      PowerOFF_Count;   
    uint16      Stopwait_Count;	
	  uint8       StopFlag;
	  uint8       BrakeTimerFlag;
} ONVarible;



typedef struct
{
		uint16 Led_ms_cnt;               // 
		uint8  Led_onoff_cnt;            // 一亮 or 一灭 都进行一次计数
		uint16 Period_cnt;               // 闪灯周期
		uint16 Period_ms_cnt;            // 电平翻转计数    
        uint8  LedFlag;                  // 闪灯完毕标志位
}MCLedDisplay;



typedef struct
{
	  uint16 mcDcbusFlt;              // 母线电压
	  int16  SpeedFlt;                // 当前速度滤波后的值
      uint16 ChargeStep;              // 预充电的步骤
      uint16 State_Count;	            // 电机各个状态的时间计数
      uint16 MosTempDecFlt;           // Mos温度
	  uint16 BatTempDecFlt;           // 电池包温度
	   uint16 mcDcbusFlt1;
}FOCCTRL;



typedef struct
{

	  uint16  BLDC_Value;
 		uint16  MDU_A;
		uint16  MDU_B;        
		int8    FlagONOFF;
	  int8    FlagONOFFtest;
    uint16  Motor_Duty_ADD_Cnt;
    uint16  Motor_Duty_SUB_Cnt;
		uint16  RUN_Cnt;    //运行时间计时
	  uint16  STALL_Cnt;	//低速堵转计时
	  uint16  On_Cnt;     //开关延时计数
    uint16  Off_Cnt;    //开关延时计数
		uint8  BatReady_flag;  //正常启动标志
	  uint8  checkbatfinish; //防飞车检测标志位  
	  uint8  flag11;      
	  uint8  BUTTON_cnt;   
	  uint8  CURRENT_cnt2;  
}MCRAMP;
 



typedef struct
{
	  uint8  FR;          //当前给定的转子方向
	  uint8	 TargetFR;    //设置的目标方向
    
} MotorFRTypeDef;


typedef struct
{
	  uint8   BDIF_Flag;              //	  续流屏蔽标志位
    uint8   FirstStep;
    
	  uint16  CR4;                    //     当前载波导通状态
    uint16  CR4_Last;	            //     上一个载波导通状态
    
    uint8   NowPhase;               //     当前导通相
    uint8   LastPhase;	            //     上一个导通相
	
	  uint16  DBR[8];                 //	   导通状态赋值
    
    uint16  DBR_ERROR[8];           //	   导通状态赋值

    uint16  PWM_COUNT_SUM;          //     载波个数求和
	  uint16  PWM_COUNT;              //	   载波计算个数
 	  uint16  PWM_COUNT_LPF;          //	   载波个数平均   
	  uint16  PWM_COUNT_Last;         //	   上一个扇区的载波计算个数
    uint8   First_Step;

    uint8   HFI_STEEP;              //     载波   
    uint8   HTS_CNT;                //	   硬件运行切换至软件运行计数值   
    uint16  Delay_PWM_COUNT;        //启动换相延迟载波个数
		uint16  Delay_Flag;             //启动换相延迟标志
		uint16  Delay_Times;            //启动换相延迟次数
		uint8   SW_FORSE;
		
		uint8   COM_Flag;                //	   换相标志位 
    uint8   Level;                   //	   电平信号
    uint8   Edge_Flt_cnt;            //	   反电动势信号滤波计数值
		uint16  COM_COUNT;               //	   软件换相计数值
    uint16  Right_COUNT;             //	   正确换相计数值
    uint16  Force_COUNT;             //	   强制换相计数值
		
		uint8   ON_OFF_FLAG;             //	   0 -- off采样   1 -- on采样
    
} BLDC_HALL_PARA;


typedef struct
{
  uint8  Updata_flag;                //  载波更新标志位
  uint8  LCOK_flag;                  //  载波更新自锁标志位
    
  uint8  SpeedUp_CNT;                //	 速度上升计数值
  uint8  SpeedDown_CNT;              //	 速度下降计数值   
  uint8  Speed_Range;                //  速度区间    
    
} PWM_FREQUENCY_CHANGE_PARA;



/* Exported variables ---------------------------------------------------------------------------*/

extern FaultVarible     xdata 		mcFaultDect;
extern ONVarible        xdata       ONOFFTest;
extern FaultStateType	xdata	  	mcFaultSource;
extern FOCCTRL          xdata 		mcFocCtrl;
extern MCLedDisplay     xdata       mcLedDisplay;
extern MCRAMP           xdata       mcSpeedRamp;
extern uint16 					xdata       VSP;
extern uint16           xdata   		VSPCopy;
extern VSPCtrlTypeDef   xdata       VSPCtrl;
extern MotorFRTypeDef	xdata       mcFRState;
extern uint16           xdata       Pdelay_time;
extern uint8            xdata       Time_1ms;
extern uint8  			xdata       Motor_Direction;
extern BLDC_HALL_PARA   xdata       BLDC_HALL;
extern PWM_FREQUENCY_CHANGE_PARA xdata FE;

extern uint8  xdata  HALL_TO_CR4_CW[7];
extern uint8  xdata  HALL_TO_CR4_CCW[7];
extern uint32 idata  SpeedScaler32_WIND;
extern uint16 idata  TIM2_CNT;
extern int16  idata  RES_MDU;
extern uint16 idata  RUN_UPLF,RUN_UCOP;
extern uint16 idata  LAST_ADC, ON_ADC ,LAST_VCC, ON_VCC;
extern uint16 idata  KR, KF, R_Voltage, F_Voltage, Voltage_Min, Back_K,BACK_Voltage;
extern uint16 xdata  HALL_VALUE;
extern uint16 xdata  KeyReady;
extern uint8  xdata   SpeedLevel;

extern uint16 xdata  TempMinCnt;
extern uint8  xdata  TempMinPhase;

extern uint16 xdata   ON_CNT;
extern uint16 xdata   OFF_CNT;
extern uint16 xdata  RampDeal_Temp_Data, RampDeal_Temp;

extern uint16 xdata  BLDC_TIM_KR[20];

extern uint16 xdata  BLDC_TIM_KF[20];

extern uint16 xdata  BLDC_SPEED[20];

extern uint16 xdata  TEST[4];
extern uint16 BLDC150_delay_Count;
extern uint16 xdata  Motor_BCCR_Flag;
extern uint16  xdata  Advance_AngleDely_Data;

/* Exported functions ---------------------------------------------------------------------------*/
extern void Fault_OverUnderVoltage(FaultVarible *h_Fault);
extern void Fault_Overcurrent(FaultVarible *h_Fault);
extern void Fault_Overcurrent1(FaultVarible *h_Fault);
extern void Fault_Overcurrent2(FaultVarible *h_Fault);

extern void  BLDC_StallProtect(void);
extern void  VariablesPreInit(void);
extern void  Fault_Detection(void);
extern int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue);
extern void  Led_OnOff( uint8 htime,uint16 onoffms , uint8 period ,uint16 periodms);
extern void  VSPSample(void);
extern  int16 SoftLPF(int16 Xn1, int16 Xn0, int16 K);
extern void  LED_Display(void);
// extern void Power_Display(void);
extern void  TouchOnOffMode(void);
extern void  SpeedSwicth(void);
extern void  FaultProcess(void);
extern void  SpeedRegulation(void);
extern int16 LPFFunction(int16 Xn1, int16 Xn0, int8 K);

extern void ON_OFF_Exchange(void);

extern uint32 Abs_F32(int32 value);
extern uint16 Abs_F16(int16 value);
extern void MULDIV_test(void);
extern void TailWindSpeedDetect(void);
extern void RDOutput(void);
extern void CurrentLimit_1ms(void);
extern void Duty_Function(void);
extern void Pdelay_Function(void);
extern void PWMCount_LPF( void );
extern unsigned char Get_Hall_Status(void);
extern void StarRampDealwith(void);
extern void SPEED_Range_Determine(void);
extern void FE_FUNCTION(void);
extern void Delay_12us(void);

/* 启动补偿后的PWM计数值 */
typedef struct
{
    uint16 Init;       /* 最初的2.5% */
    uint16 Duty0;      /* 第1档 */
    uint16 Duty1;      /* 第2档 */
    uint16 Duty2;      /* 第3档 */
    uint16 Duty3;      /* 第4档 */
    uint16 Max;        /* 启动上限 */
} StartDutyType;

extern volatile StartDutyType xdata StartDuty;
extern uint8 StartDuty_Prepare(void);

#endif
