/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
    File Name          : AddFunction.c
    Author             : Fortiortech  Appliction Team
    Version            : V1.0
    Date               : 2017-12-26
    Description        : This file contains all the add function used for Motor Control.
***************************************************************************************************
    All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/

#include <FU68xx_2.h>
#include <Myproject.h>
#include <CurrentLimitLogic.h>

/* Private variables ---------------------------------------------------------*/
FaultStateType             mcFaultSource;
FaultVarible       xdata   mcFaultDect;
FOCCTRL            xdata   mcFocCtrl;
ONVarible          xdata   ONOFFTest;
MCLedDisplay       xdata   mcLedDisplay;
MCRAMP             xdata   mcSpeedRamp;
MotorFRTypeDef     xdata   mcFRState;
uint16             xdata   VSP;
uint16             xdata   VSPCopy;
VSPCtrlTypeDef     xdata   VSPCtrl;
uint8              xdata   Time_1ms;
uint8              xdata   Motor_Direction;

#define START_VREF_Q15 \
    ((uint16)_Q15(12.0 / HW_BOARD_VOLT_MAX))
#define START_VMIN_Q15 \
    ((uint16)_Q15(7.5 / HW_BOARD_VOLT_MAX))
#define START_VMAX_Q15 \
    ((uint16)_Q15(16.5 / HW_BOARD_VOLT_MAX))

volatile StartDutyType xdata StartDuty;

/* 实际PWM计数 = 12V基准PWM计数 × 12V / 当前母线电压 */
static uint16 StartDuty_Scale(uint16 dutyRef, uint16 busQ15)
{
    return (uint16)(((uint32)dutyRef * START_VREF_Q15
                     + busQ15 / 2U) / busQ15);
}

/* 每次启动前调用一次：1=参数有效，0=电压不符合启动范围 */
uint8 StartDuty_Prepare(void)
{
    uint16 busQ15;

    busQ15 = mcFocCtrl.mcDcbusFlt;

    /* 包括防止采样为0时发生除零 */
    if ((busQ15 < START_VMIN_Q15) ||
        (busQ15 > START_VMAX_Q15))
    {
        return 0;
    }

    StartDuty.Init  = StartDuty_Scale(MIN_BLDC_Duty, busQ15);
    StartDuty.Duty0 = StartDuty_Scale(BLDC_Start_Duty0, busQ15);
    StartDuty.Duty1 = StartDuty_Scale(BLDC_Start_Duty1, busQ15);
    StartDuty.Duty2 = StartDuty_Scale(BLDC_Start_Duty2, busQ15);
    StartDuty.Duty3 = StartDuty_Scale(BLDC_Start_Duty3, busQ15);
    StartDuty.Max   = StartDuty_Scale(MAX_Start_Duty, busQ15);

    return 1;
}

static void VSP_ProcessState(void);
static uint16 xdata Limit_DutyRef;

static void CurrentLimitSetDutyRef(uint16 dutyRef)
{
    bool tempEA;

    tempEA = EA;
    EA = 0;
    Limit_DutyRef = dutyRef;
    EA = tempEA;
}



BLDC_HALL_PARA xdata BLDC_HALL;

uint8  xdata  HALL_TO_CR4_CW[7]  = { 0, 1, 3, 2, 5, 6, 4};

uint8  xdata  HALL_TO_CR4_CCW[7] = { 0, 4, 6, 5, 2, 3, 1};
PWM_FREQUENCY_CHANGE_PARA xdata FE;

uint32 idata  SpeedScaler32_WIND = 0;
uint16 idata  TIM2_CNT  = 0;
int16  idata  RES_MDU= 0;
uint16 idata  RUN_UPLF,RUN_UCOP = 0;
uint16  ON_PdelayTime = 0;
uint16  OFF_PdelayTime = 0;
uint16  xdata   KeyCount_Dw=0,KeyCount_Up=0,KeyDwFlag=0,KeyReady;
uint16  xdata   KeyCount_Dw_SW=0,KeyCount_Up_SW=0,KeyDwFlag_SW=0;
uint8   xdata   SpeedLevel;
uint16  xdata   TEST[4] = 0;
uint16  xdata   ON_CNT;
uint16  xdata   OFF_CNT;
uint16  xdata   Motor_BCCR_Flag;
uint16  xdata   Advance_AngleDely_Data;
uint16  xdata   RampDeal_Temp_Data, RampDeal_Temp;
uint16          BLDC150_delay_Count = 0;


/* -------------------------------------------------------------------------------------------------
    Function Name  : KLPF_VALUE
    Description    : 一阶低通滤波器
    Date           : 2022-02-21
    Parameter      : INVlaue: [输入/出] 
    OutLastValue   : [输入/出] 
------------------------------------------------------------------------------------------------- */
int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
{
    int16 Result = 0;
    MDU_MA = (INVlaue - OutLastValue);
    MDU_MB = (int16)480;                            /*写被乘数和乘数*/
    Result = MDU_MB;
    Result += OutLastValue;
    return (Result);
}



/* -------------------------------------------------------------------------------------------------
    Function Name  : FaultProcess
    Description    : 错误处理函数，用于在发生错误以后关闭MOS管的输出。
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void FaultProcess(void)
{
	  
    MOE     =  0;
    TIM1_CR0 = 0;
    TIM1_CR1 = 0;
    TIM1_CR2 = 0;
    TIM1_CR3 = 0;
    TIM1_CR4 = 7;
    TIM1_IER = 0;
    FOC_CR1    = 0x00;
    DRV_DR     = 0;    //刹车力度
    /*关闭FOC*/
    ClrBit(DRV_CR, FOCEN);
    mcLedDisplay.LedFlag = 1;
    Driver_Init();
}



/* -------------------------------------------------------------------------------------------------
    Function Name  : Abs_F16
    Description    : int16位数据取绝对值
    Date           : 2022-02-21
    Parameter      : value: [输入/出] 
------------------------------------------------------------------------------------------------- */
uint16 Abs_F16(int16 value)
{
    if (value < 0)
    {
        return (- value);
    }
    else
    {
        return (value);
    }
}






/* -------------------------------------------------------------------------------------------------
    Function Name  : Abs_F32
    Description    : int32位变量取绝对值
    Date           : 2022-02-21
    Parameter      : value: [输入/出] 
------------------------------------------------------------------------------------------------- */
uint32 Abs_F32(int32 value)
{
    if (value < 0)
    {
        return (- value);
    }
    else
    {
        return (value);
    }
}



/* -------------------------------------------------------------------------------------------------
    Function Name  : Fault_Overcurrent
    Description    : 一阶软件过流函数
    Date           : 2022-02-21
    Parameter      : h_Fault: [输入/出] 
------------------------------------------------------------------------------------------------- */
void Fault_Overcurrent(FaultVarible * h_Fault)
{
    if (Power_Currt2 >= OverSoftCurrent)
    {
        h_Fault->OverCurrentCnt++;
        
        if (h_Fault->OverCurrentCnt >= OverSoftCurrentTime)
        {
            h_Fault->OverCurrentCnt = 0;
            h_Fault->OverCurrentCnt1 = 0;
            h_Fault->OverCurrentCnt2 = 0;
            mcFaultSource = FaultSoftOVCurrent;
					  mcFaultDect.OC_Recover_CNT = PROTECTION_OverSoftCurrent_RECOVER_TIMES;
            FaultProcess();
            mcState                = mcFault;
        }
    }
    else
    {
        if (h_Fault->OverCurrentCnt > 0)
        {
            h_Fault->OverCurrentCnt--;
        }
        
        if (h_Fault->OverCurrentCnt1 > 0)
        {
            h_Fault->OverCurrentCnt1--;
        }
        
        if (h_Fault->OverCurrentCnt2 > 0)
        {
            h_Fault->OverCurrentCnt2--;
        }
    }
}





/* -------------------------------------------------------------------------------------------------
    Function Name  : Fault_Overcurrent1
    Description    : 二阶软件过流
    Date           : 2022-02-21
    Parameter      : h_Fault: [输入/出] 
------------------------------------------------------------------------------------------------- */
void Fault_Overcurrent1(FaultVarible * h_Fault)
{
    if (Power_Currt2 >= OverSoftCurrent1)
    {
        h_Fault->OverCurrentCnt1++;
        
        if (h_Fault->OverCurrentCnt1 >= OverSoftCurrentTime1)
        {
            h_Fault->OverCurrentCnt = 0;
            h_Fault->OverCurrentCnt1 = 0;
            h_Fault->OverCurrentCnt2 = 0;
            mcFaultSource = FaultSoftOVCurrent1;
					  mcFaultDect.OC_Recover_CNT = PROTECTION_OverSoftCurrent_RECOVER_TIMES;
            FaultProcess();
            mcState                = mcFault;
        }
    }
    else
    {
        if (h_Fault->OverCurrentCnt1 > 0)
        {
            h_Fault->OverCurrentCnt1--;
        }
        
        if (h_Fault->OverCurrentCnt2 > 0)
        {
            h_Fault->OverCurrentCnt2--;
        }
    }
}







/* -------------------------------------------------------------------------------------------------
    Function Name  : Fault_Overcurrent2
    Description    : 三阶软件过流
    Date           : 2022-02-21
    Parameter      : h_Fault: [输入/出] 
------------------------------------------------------------------------------------------------- */
void Fault_Overcurrent2(FaultVarible * h_Fault)
{
    if (Power_Currt2 >= OverSoftCurrent2)
    {
        h_Fault->OverCurrentCnt2++;
        
        if (h_Fault->OverCurrentCnt2 >= OverSoftCurrentTime2)
        {
            h_Fault->OverCurrentCnt = 0;
            h_Fault->OverCurrentCnt1 = 0;
            h_Fault->OverCurrentCnt2 = 0;
            mcFaultSource = FaultSoftOVCurrent2;
					  mcFaultDect.OC_Recover_CNT = PROTECTION_OverSoftCurrent_RECOVER_TIMES;
            FaultProcess();
            mcState                = mcFault;
        }
    }
    else
    {
        if (h_Fault->OverCurrentCnt2 > 0)
        {
            h_Fault->OverCurrentCnt2--;
        }
    }
}







/* -------------------------------------------------------------------------------------------------
    Function Name  : Fault_OverUnderVoltage
    Description    : 过欠压保护
    Date           : 2022-02-21
    Parameter      : h_Fault: [输入/出] 
------------------------------------------------------------------------------------------------- */
void Fault_OverUnderVoltage(FaultVarible * h_Fault)
{
    if (mcFaultSource == FaultNoSource)
    {
        //过压保护
        if (mcFocCtrl.mcDcbusFlt > OVER_PROTECT_VALUE)
        {
            h_Fault->OverVoltDetecCnt++;
            
            if (h_Fault->OverVoltDetecCnt > 30)
            {
                h_Fault->OverVoltDetecCnt = 0;

                mcFaultSource = FaultOverVoltage;
                FaultProcess();
                mcState                = mcFault;
            }
        }
        else
        {
            if (h_Fault->OverVoltDetecCnt > 0)
            {
                h_Fault->OverVoltDetecCnt--;
            }
        }
        
        //欠压保护
        if (mcFocCtrl.mcDcbusFlt < UNDER_PROTECT_VALUE)
        {
            h_Fault->UnderVoltDetecCnt++;
            
            if (h_Fault->UnderVoltDetecCnt > 3000)
            {   
                h_Fault->UnderVoltDetecCnt = 0;
                mcFaultSource = FaultUnderVoltage;
                FaultProcess();
                mcState                = mcFault;
            }
        }
        else
        {
            if (h_Fault->UnderVoltDetecCnt > 0)
            {
                h_Fault->UnderVoltDetecCnt--;
            }
        }
    }
		 if(mcFaultSource == FaultUnderVoltage){
			 if(mcFocCtrl.mcDcbusFlt >= UNDER_RECOVER_VALUE)  mcFaultSource = FaultNoSource;			 
		 }
		 if(mcFaultSource == FaultOverVoltage){
       if(mcFocCtrl.mcDcbusFlt < OVER_RECOVER_VALUE) mcFaultSource = FaultNoSource;	
		 }
}







/* -------------------------------------------------------------------------------------------------
    Function Name  : Fault_MosTemperature
    Description    : 过温保护
    Date           : 2022-02-21
    Parameter      : h_Fault: [输入/出] 
------------------------------------------------------------------------------------------------- */
void Fault_MosTemperature(FaultVarible * h_Fault)
{
    if (mcFocCtrl.MosTempDecFlt < OVER_Mos_Temperature)
    {
        h_Fault->MosTemperCnt++;        
        if (h_Fault->MosTemperCnt > 500)
        {
            h_Fault->MosTemperCnt = 0;           
            mcFaultSource = FaultMosOverTemperature;
            FaultProcess();
            mcState                = mcFault;
        }
    }
    else if (h_Fault->MosTemperCnt > 0)
    {
        h_Fault->MosTemperCnt --;
    }
		
		if(mcFaultSource == FaultMosOverTemperature){
			if (mcFocCtrl.MosTempDecFlt > UNDER_Mos_Temperature) {			
				h_Fault->MosTemperRecover++;
				if(h_Fault->MosTemperRecover > Over_Mos_TemperRecoverTime){
						h_Fault->MosTemperRecover = 0;
						mcFaultSource = FaultNoSource;
				}
			}
            else
            {
                h_Fault->MosTemperRecover = 0;
            }
		}
}







/* -------------------------------------------------------------------------------------------------
    Function Name  : Fault_BatTemperature
    Description    : 电池包温度保护
    Date           : 2022-02-21
    Parameter      : h_Fault: [输入/出] 
------------------------------------------------------------------------------------------------- */
void Fault_BatTemperature(FaultVarible * h_Fault)
{
    if (mcFocCtrl.BatTempDecFlt < OVER_Bat_Temperature)
    {
        h_Fault->BatTemperCnt++;
        
        if (h_Fault->BatTemperCnt > 500)
        {
            h_Fault->BatTemperCnt = 0;
            h_Fault->BatTemperRecover = 0;
            mcFaultSource = FaultBatOverTemperature;
            FaultProcess();
            mcState                = mcFault;
        }
    }
    else if (h_Fault->BatTemperCnt > 0)
    {
        h_Fault->BatTemperCnt --;
    }

    if(mcFaultSource == FaultBatOverTemperature){
        if (mcFocCtrl.BatTempDecFlt > UNDER_Bat_Temperature) {
            h_Fault->BatTemperRecover++;
            if(h_Fault->BatTemperRecover > Over_Bat_TemperRecoverTime){
                h_Fault->BatTemperRecover = 0;
                mcFaultSource = FaultNoSource;
            }
        }
        else
        {
            h_Fault->BatTemperRecover = 0;
        }
    }
}








/* -------------------------------------------------------------------------------------------------
    Function Name  : BLDC_StallProtect
    Description    : 低速电机堵转保护
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void BLDC_StallProtect(void)
{
   
    if( BLDC_HALL.PWM_COUNT >= RUN_STALL_COUNT )
    {
        /*堵转保护*/
        mcFaultSource = FaultStall;
        BLDC_HALL.PWM_COUNT = 0;
        FaultProcess();
			  mcFaultDect.Stall_Recover_CNT = PROTECTION_STALL_RECOVER_TIMES;
        mcState  = mcFault;
    }


     
    if( mcState == mcRun )    
    {
        /*失步错误换相保护*/
        if (    (TIM1_BCOR  < RUN_STALLRPM_COUNT) && (TIM1_BCOR  > 0)
             && (TIM1__BCCR < RUN_STALLRPM_COUNT) && (TIM1__BCCR > 0)
           )
        {
            mcFaultSource = FaultLostStep;
            FaultProcess();
					  mcFaultDect.Stall_Recover_CNT = 0;
            mcState                = mcFault;
        }
    }
     
}






/* -------------------------------------------------------------------------------------------------
    Function Name  : Fault_Detection
    Description    : 保护函数合集
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Fault_Detection(void)
{
    #if (OverSoftCurrentProtect == Enable)
    {
        Fault_Overcurrent(&mcFaultDect);               // 一级软件过流保护
    }
    #endif
    
    
   #if (OverSoftCurrentProtect1 == Enable)
    {
        Fault_Overcurrent1(&mcFaultDect);              // 二级软件过流保护
    }
    #endif
    
    
    #if (OverSoftCurrentProtect2 == Enable)
    {
        Fault_Overcurrent2(&mcFaultDect);              // 三级软件过流保护
    }
    #endif
    
    
    #if (VoltageProtect == Enable)
    {
        Fault_OverUnderVoltage(&mcFaultDect);          // 电压保护
    }
    #endif
    
    
    #if (Mos_TemperatureProtectEnable == Enable)
    {
        Fault_MosTemperature(&mcFaultDect);            // Mos温度保护
    }
    #endif
    
    
    #if (Bat_TemperatureProtectEnable == Enable)
    {
        Fault_BatTemperature(&mcFaultDect);            // Bat温度保护
    }
    #endif
    

      if (mcFaultDect.Stall_Recover_CNT != 0)
         mcFaultDect.Stall_Recover_CNT -= 1;
			if (mcFaultDect.OC_Recover_CNT != 0)
				 mcFaultDect.OC_Recover_CNT -= 1;

			if((mcFaultSource == FaultStall || mcFaultSource == FaultLostStep)&& mcFaultDect.Stall_Recover_CNT==0){  mcFaultSource = FaultNoSource;}
      if((mcFaultSource == FaultSoftOVCurrent || mcFaultSource == FaultSoftOVCurrent1 || mcFaultSource == FaultSoftOVCurrent2 ||mcFaultSource == FaultHardOVCurrent) && mcFaultDect.OC_Recover_CNT==0){
			   mcFaultSource = FaultNoSource;
			}
			BuzzAlarm_FaultTrigger();
}






/* -------------------------------------------------------------------------------------------------
    Function Name  : SoftLPF
    Description    : 软件低通滤波函数
    Date           : 2022-02-21
    Parameter      : Xn1: [输入/出]   Xn0: [输入/出]   K: [输入/出] 
------------------------------------------------------------------------------------------------- */
int16 SoftLPF(int16 Xn1, int16 Xn0, int16 K)
{
    int16 temp16 = 0;
    int32 Temp32 = 0;
    Temp32 = (((int32)Xn1 - (int32)Xn0) * (int32)K) >> 15;
    temp16 = Xn0 + (int16)Temp32;
    return temp16;
}





/* -------------------------------------------------------------------------------------------------
    Function Name  : LED_Display
    Description    : LED显示
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void LED_Display(void)
{
    switch (mcFaultSource)
    {
        case FaultNoSource:
                    ResetLEDPin;                                                    //低电平点亮，高电平灭
                    mcLedDisplay.LedFlag = 0;
                    mcLedDisplay.Led_onoff_cnt = 0;
                    mcLedDisplay.Led_ms_cnt = 0;
                    mcLedDisplay.Period_cnt = 0;      
                    mcLedDisplay.Period_ms_cnt = 0;
            break;
            
        case FaultSoftOVCurrent:
                Led_OnOff(1,300, 3,1000);
            break;
            
        case FaultSoftOVCurrent1:
                Led_OnOff(2,300, 3,1000);
            break;
            
        case FaultSoftOVCurrent2:
                Led_OnOff(3,300, 3,1000);
            break;
            
        case FaultHardOVCurrent:
                Led_OnOff(4,300, 3,1000);
            break;
            
        case FaultUnderVoltage:
                Led_OnOff(5,300, 3,1000);
            break;
            
        case FaultOverVoltage:
                Led_OnOff(6,300, 3,1000);
            break;
            
        case FaultMosOverTemperature:
                Led_OnOff(7,300, 3,1000);
            break;
            
        case FaultBatOverTemperature:
                Led_OnOff(8,300, 3,1000);
            break;
            
        case FaultLossPhase:
                Led_OnOff(9,300, 3,1000);
            break;
            
        case FaultStall:
                Led_OnOff(10,300, 3,1000);
            break;
            
        case FaultLostStep:
                Led_OnOff(11,300, 3,1000);
            break;
        
        case FaultLVW:
                Led_OnOff(12,300, 3,1000);
            break;
        case FaultAntiFlying:
                Led_OnOff(13,300, 3,1000);
            break;
        case FaultVSPInvalid:
                Led_OnOff(14,300, 3,1000);
            break;
        default:
            break;
    }
}






/* -------------------------------------------------------------------------------------------------
    Function Name  : Led_OnOff
    Description    : LED开关控制函数
    Date           : 2022-02-21
    Parameter      : hLedDisplay: [输入/出] 	 htime: [每一个周期闪灯次数]    闪灯的周期数：2
------------------------------------------------------------------------------------------------- */
void Led_OnOff( uint8 htime,uint16 onoffms , uint8 period ,uint16 periodms)
{
   if(mcLedDisplay.LedFlag == 1)                         // 检测到需要闪灯
   {
      if( mcLedDisplay.Led_onoff_cnt > 2*htime-1)
      {
            ResetLEDPin;                                  //  将LED灯关闭
          
            if(mcLedDisplay.Period_ms_cnt < periodms)
            {
                mcLedDisplay.Period_ms_cnt++;
            }
            else                                          //  达到LED灯设置的关闭时长，开始下一个周期的闪灯
            {
                mcLedDisplay.Led_onoff_cnt = 0;
                mcLedDisplay.Period_ms_cnt = 0;
                mcLedDisplay.Period_cnt++; 
                if( mcLedDisplay.Period_cnt >= period)     //   超过需要闪的周期，停止闪灯
                {
                    mcLedDisplay.LedFlag = 0;            
                }
            }
      }
      else
      {
          if(mcLedDisplay.Led_ms_cnt< onoffms)
          {
                mcLedDisplay.Led_ms_cnt++;
          }
          else
          {
                mcLedDisplay.Led_ms_cnt = 0;             
                mcLedDisplay.Led_onoff_cnt++;           //  记录亮灭次数
                LEDPinONOFF;
          }
      }
   }
   else                                                // 不需要闪灯
   {
       mcLedDisplay.Led_onoff_cnt = 0;
       mcLedDisplay.Led_ms_cnt = 0;
       mcLedDisplay.Period_cnt = 0;      
       mcLedDisplay.Period_ms_cnt = 0;
   }
}















/* -------------------------------------------------------------------------------------------------
    Function Name  : LPFFunction
    Description    : 硬件低通滤波
    Date           : 2022-02-21
    Parameter      : Xn1: [输入/出] 	 Xn0: [输入/出] 	 K: [输入/出] 
------------------------------------------------------------------------------------------------- */
int16 LPFFunction(int16 Xn1, int16 Xn0, int8 K)
{
    LPF_K = K;
    LPF_X = Xn1;
    LPF_Y = Xn0;
    SetBit(PI_LPF_CR, LPFSTA);
    _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    return LPF_Y;
}











/* -------------------------------------------------------------------------------------------------
    Function Name  : VSPSample
    Description    : 电位器调速
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
static uint16 VSP_AddLimit(uint16 base, uint16 delta)
{
    if (base >= (MAX_Duty - delta))
    {
        return MAX_Duty;
    }
    else
    {
        return (base + delta);
    }
}


/*
 * 根据采到的释放态偏置更新VSP启停阈值。
 * 启动阈值 = 偏置 + 0.20V；停止阈值 = 偏置 + 0.07V。
 * 启动阈值和停止阈值之间为迟滞区间，避免扳机电压抖动导致频繁启停。
 * 速度曲线最小转速点跟随启动阈值，按下刚启动时即对应MOTOR_SPEED_MIN_RPM。
 */
static void VSP_ApplyOffset(uint16 offset)
{
    VSPCtrl.Offset      = offset;
    VSPCtrl.OnDuty      = VSP_AddLimit(VSPCtrl.Offset, VSP_ON_DELTA);
    VSPCtrl.OffDuty     = VSP_AddLimit(VSPCtrl.Offset, VSP_OFF_DELTA);
    VSPCtrl.MinDuty     = VSPCtrl.OnDuty;
    VSPCtrl.OffsetReady = 1;
}


/*
 * 判断释放态偏置是否在硬件允许范围内。
 * 这里只判断电压窗口是否合理，不判断扳机是否真的处于物理释放状态。
 * 注意：该函数只用于上电采样和故障恢复采样，READY状态绝不重新采样偏置。
 */
static uint8 VSP_IsOffsetValid(uint16 offset)
{
    if ((offset < VSP_OFFSET_MIN) || (offset > VSP_OFFSET_MAX))
    {
        return 0;
    }
    else
    {
        return 1;
    }
}


static void VSP_ResetInitSample(void)
{
    /* 上电主偏置采样变量和故障恢复采样变量分开，避免恢复流程清掉上电采样进度。 */
    VSPCtrl.InitOffsetSum = 0;
    VSPCtrl.InitOffsetCnt = 0;
}


static void VSP_ResetRecoverSample(void)
{
    /* 故障恢复采样独立计数；非法后每轮6S等待结束都会重新开始一组平均。 */
    VSPCtrl.RecoverOffsetSum = 0;
    VSPCtrl.RecoverOffsetCnt = 0;
}


/* 进入VSP非法故障提示流程。
   这里只设置故障和状态，不直接启动蜂鸣，避免和通用故障蜂鸣形成双入口。 */
static void VSP_EnterInvalidFault(void)
{
    VSPCtrl.State = VSP_STATE_FAULT_BEEP;
    VSPCtrl.BeepStarted = 0;
    VSPCtrl.FaultWaitCnt = 0;
    VSPCtrl.OffsetReady = 0;
    VSP_ResetRecoverSample();
    mcSpeedRamp.FlagONOFF = 0;
    ONOFFTest.StopFlag = 0;

    if ((mcFaultSource == FaultNoSource) || (mcFaultSource == FaultVSPInvalid))
    {
        mcFaultSource = FaultVSPInvalid;
        FaultProcess();
        mcState = mcFault;
    }
}





static void VSP_ProcessInitStable(void)
{
    /* 上电后先等ADC和低通滤波结果稳定，再开始采偏置，避免把上电瞬态当成释放电压。 */
    if (VSPCtrl.InitStableCnt < VSP_OFFSET_STABLE_CNT)
    {
        VSPCtrl.InitStableCnt++;
        return;
    }

    VSP_ResetInitSample();
    VSPCtrl.State = VSP_STATE_INIT_SAMPLE;
}


static void VSP_ProcessInitSample(void)
{
    uint16 VSPAvg;

    /* 上电主偏置只采一次。采满VSP_OFFSET_SAMPLE_NUM次后求平均，合法则进入READY。 */
    VSPCtrl.InitOffsetSum += VSP;
    VSPCtrl.InitOffsetCnt++;
    if (VSPCtrl.InitOffsetCnt < VSP_OFFSET_SAMPLE_NUM)
    {
        return;
    }

    VSPAvg = (uint16)(VSPCtrl.InitOffsetSum >> VSP_OFFSET_SAMPLE_SHIFT);
    VSP_ResetInitSample();

    if (VSP_IsOffsetValid(VSPAvg))
    {
        VSP_ApplyOffset(VSPAvg);
        VSPCtrl.State = VSP_STATE_READY;
    }
    else
    {
        VSP_EnterInvalidFault();
    }
}


static void VSP_ProcessFaultBeep(void)
{

    if (BuzzCtrl.Mode == BUZZ_MODE_STARTUP)
    {
        /* 开机音优先播放；VSP非法报警延后，避免两套声音抢同一个蜂鸣驱动。 */
        return;
    }

    if (VSPCtrl.BeepStarted == 0)
    {
        if (BuzzCtrl.MusicEnable)
        {
            return;
        }

        VSPCtrl.BeepStarted = 1;
        /* VSP故障三声报警只从这里触发，通用故障蜂鸣入口会跳过FaultVSPInvalid。 */
        BuzzMusic_PlayAlarmOnce(ALARM_TYPE_TEMP);
        return;
    }

    if (BuzzCtrl.MusicEnable)
    {
        return;
    }

    VSPCtrl.BeepStarted = 0;
    VSPCtrl.FaultWaitCnt = 0;
    VSP_ResetRecoverSample();
    VSPCtrl.State = VSP_STATE_FAULT_WAIT;
}


static void VSP_ProcessFaultWait(void)
{

    if (VSPCtrl.FaultWaitCnt < 2000)//VSP_INVALID_RECOVER_TIME
    {
        /* 三声报警结束后等待2S，不在等待期间采样，降低误恢复概率。 */
        VSPCtrl.FaultWaitCnt++;
        return;
    }

    VSP_ResetRecoverSample();
    VSPCtrl.State = VSP_STATE_FAULT_SAMPLE;
}


static void VSP_ProcessFaultSample(void)
{
    uint16 VSPAvg;

    /*
     * 6S后做一组独立恢复平均。
     * 局限：这里按需求只判断VSP电压是否落在释放偏置合法范围内；
     * 如果用户一直半按且电压刚好落在合法窗口，软件无法单靠电压判断其真实释放状态。
     */
    VSPCtrl.RecoverOffsetSum += VSP;
    VSPCtrl.RecoverOffsetCnt++;
    if (VSPCtrl.RecoverOffsetCnt < VSP_OFFSET_SAMPLE_NUM)
    {
        return;
    }

    VSPAvg = (uint16)(VSPCtrl.RecoverOffsetSum >> VSP_OFFSET_SAMPLE_SHIFT);
    VSP_ResetRecoverSample();
    VSPCtrl.FaultWaitCnt = 0;

    if (VSP_IsOffsetValid(VSPAvg))
    {
        /* 恢复平均值合法：重新生成启停阈值，清除VSP故障，让电机回到停止待命状态。 */
        VSP_ApplyOffset(VSPAvg);
        VSPCtrl.State = VSP_STATE_READY;
        VSPCtrl.BeepStarted = 0;
        mcSpeedRamp.FlagONOFF = 0;
        ONOFFTest.StopFlag = 0;

        if (mcFaultSource == FaultVSPInvalid)
        {
            mcFaultSource = FaultNoSource;
        }
        if (mcState == mcFault)
        {
            mcState = mcStop;
        }
    }
    else
    {
        /* 仍然非法：重新进入三声报警 -> 6S等待 -> 多次平均检测的循环。 */
        VSP_EnterInvalidFault();
    }
}


/* VSP状态机入口，1ms调用一次。
   READY状态只做启停判断，绝不重新采偏置，避免把按下扳机误当释放电压。 */
static void VSP_ProcessState(void)
{
    switch ((VSPStateType)VSPCtrl.State)
    {
        case VSP_STATE_INIT_STABLE:
            VSP_ProcessInitStable();
            break;

        case VSP_STATE_INIT_SAMPLE:
            VSP_ProcessInitSample();
            break;

        case VSP_STATE_READY:
            break;

        case VSP_STATE_FAULT_BEEP:
            VSP_ProcessFaultBeep();
            break;

        case VSP_STATE_FAULT_WAIT://下次采样等待
            VSP_ProcessFaultWait();
            break;

        case VSP_STATE_FAULT_SAMPLE://恢复按键有效值判断
            VSP_ProcessFaultSample();
            break;

        default:
            VSPCtrl.State = VSP_STATE_INIT_STABLE;
            VSPCtrl.InitStableCnt = 0;
            VSP_ResetInitSample();
            VSP_ResetRecoverSample();
            break;
    }
}


/*==== 启动阶段母线电压档位 Q15阈值 ====*/
#define VOLT_THRESH1_Q15      _Q15(8.00F  / HW_BOARD_VOLT_MAX)
#define VOLT_THRESH2_Q15      _Q15(12.00F / HW_BOARD_VOLT_MAX)
#define VOLT_THRESH3_Q15      _Q15(14.50F / HW_BOARD_VOLT_MAX)

/*==== 开环DUTY缩放系数 Q15 ====*/
#define START_MID_SCALE_LOW     (uint16)(0.2 * PWM_VALUE_LOAD_BLDC)
#define START_MID_SCALE_MID1    (uint16)(0.15 * PWM_VALUE_LOAD_BLDC)
#define START_MID_SCALE_MID2    (uint16)(0.1 * PWM_VALUE_LOAD_BLDC)
#define START_MID_SCALE_HIGH    (uint16)(0.05 * PWM_VALUE_LOAD_BLDC)

/**
 * @brief 根据母线电压获取启动占空比Q15缩放系数
 * @retval Q15缩放系数
 */
static uint16 GetStartDutyScale(void)
{
    uint16 busQ15 = mcFocCtrl.mcDcbusFlt;
    if(busQ15 <= VOLT_THRESH1_Q15)
    {
        return START_MID_SCALE_LOW;
    }
    else if(busQ15 <= VOLT_THRESH2_Q15)
    {
        return START_MID_SCALE_MID1;
    }
    else if(busQ15 <= VOLT_THRESH3_Q15)
    {
        return START_MID_SCALE_MID2;
    }
    else
    {
        return START_MID_SCALE_HIGH;
    }
}

void VSPSample(void)
{
    uint16 VSPRange;
    uint16 VSPDelta;
    int16  SpeedRangeQ15;
    int32  TempS32;

    VSP_ProcessState();
    if (VSPCtrl.State != VSP_STATE_READY)
    {
        return;
    }
    if (mcFaultSource != FaultNoSource)
    {
        return;
    }

    if (mcSpeedRamp.FlagONOFF == 0)
    {
        if (VSP >= VSPCtrl.OnDuty)
        {
            mcSpeedRamp.FlagONOFF = 1;
        }
    }
    else if (VSP <= VSPCtrl.OffDuty)
    {
        mcSpeedRamp.FlagONOFF = 0;
    }

    if (mcSpeedRamp.FlagONOFF == 1)
    {
#if (SPEEND_LOOP_EN == Enable)
        {
            if (Loop_Ref.Loop_Mode == 0 || Loop_Ref.Loop_Mode == 2)
            {
                mcSpeedRamp.BLDC_Value = GetStartDutyScale();
            }

            if (VSP <= VSPCtrl.MinDuty)
            {
                PID_Speed.exp = MOTOR_SPEED_MIN_RPM;
            }
            else if (VSP < MAX_Duty)
            {
                VSPRange = MAX_Duty - VSPCtrl.MinDuty;
                VSPDelta = VSP - VSPCtrl.MinDuty;
                if (VSPRange == 0)
                {
                    PID_Speed.exp = MOTOR_SPEED_MIN_RPM;
                }
                else
                {
                    SpeedRangeQ15 = MOTOR_SPEED_MAX_RPM - MOTOR_SPEED_MIN_RPM;
                    TempS32 = (int32)SpeedRangeQ15 * VSPDelta;
                    TempS32 = TempS32 / (int32)VSPRange;
                    PID_Speed.exp = MOTOR_SPEED_MIN_RPM + (int16)TempS32;
                }
            }
            else
            {
                PID_Speed.exp = MOTOR_SPEED_MAX_RPM;
            }
        }
#else
        {
            mcSpeedRamp.BLDC_Value = MAX_BLDC_Duty;
        }
#endif
    }
    else
    {
        mcSpeedRamp.BLDC_Value = 0;
    }
}




//void VSPSample(void)
//{
//    uint16 VSPRange;
//    uint16 VSPDelta;
//    float  SpeedKTemp;

//    VSP_ProcessState();

//    if (VSPCtrl.State != VSP_STATE_READY) 
//    {
//        return;
//    }

//    if (mcFaultSource != FaultNoSource)
//    {
//        return;
//    }

//    if (mcSpeedRamp.FlagONOFF == 0)
//    {
//        /* 未启动时只比较启动阈值，不把当前VSP当作新偏置。 */
//        if (VSP >= VSPCtrl.OnDuty)
//        {
//            mcSpeedRamp.FlagONOFF = 1;
//        }
//    }
//    else if (VSP <= VSPCtrl.OffDuty)
//    {
//        /* 已启动后低于停止阈值才关机，中间区间保持原状态形成迟滞。 */
//        mcSpeedRamp.FlagONOFF = 0;
//    }
//    
//    if (mcSpeedRamp.FlagONOFF  == 1)
//    {
//			 #if (SPEEND_LOOP_EN == Enable)
//		   {															
//						if (Loop_Ref.Loop_Mode == 0 || Loop_Ref.Loop_Mode == 2)
//						{ 
//								mcSpeedRamp.BLDC_Value  = MID_BLDC_Duty;                   //启动后开环阶段目标占空比赋值
//						}
//						
//						if (VSP <= VSPCtrl.MinDuty)
//						{
//								PID_Speed.exp  = MOTOR_SPEED_MIN_RPM;
//						}
//						else if (VSP < MAX_Duty)                                                                    
//						{       
////								MDU_MA = (uint16)SPEED_K;
////								MDU_MB = (uint16)(VSP - MIN_Duty);								         //写被乘数和乘数

//								/* 启动阈值作为速度曲线最小点，保证动态偏置后低速起点跟随偏置移动。 */
//								VSPRange = MAX_Duty - VSPCtrl.MinDuty;
//								VSPDelta = VSP - VSPCtrl.MinDuty;
//								if (VSPRange == 0)
//								{
//										PID_Speed.exp = MOTOR_SPEED_MIN_RPM;
//								}
//								else
//								{
//										SpeedKTemp = (float)(MOTOR_SPEED_MAX_RPM - MOTOR_SPEED_MIN_RPM) / (float)VSPRange;
//										PID_Speed.exp  = MOTOR_SPEED_MIN_RPM + VSPDelta * SpeedKTemp;
//								}
//						}
//						else                                                                                        
//						{
//								PID_Speed.exp  = MOTOR_SPEED_MAX_RPM;
//						}
//						
//			 }
//			 #else
//			 {
////						if (VSP <= MIN_Duty)                                                                        
////						{
////								mcSpeedRamp.BLDC_Value  = MIN_BLDC_Duty;
////						}
////						else if (VSP < MAX_Duty)                                                                    
////						{       
////								MDU_MA = (uint16)BLDC_K;
////								MDU_MB = (uint16)(VSP-MIN_Duty);								         //写被乘数和乘数
////								mcSpeedRamp.BLDC_Value  = MIN_BLDC_Duty + MDU_MB;				
////						}
////						else                                                                                        
////						{
////								mcSpeedRamp.BLDC_Value  = MAX_BLDC_Duty;
////						}
//            mcSpeedRamp.BLDC_Value  = MAX_BLDC_Duty;
//			 }
//			 #endif
//    }
//    else
//    {
//        mcSpeedRamp.BLDC_Value  = 0;        
//    }
//    
//     
//}





/* -------------------------------------------------------------------------------------------------
    Function Name  : CurrentLimit_1ms
    Description    : ADC11平均母线电流渐进限流，每1ms调用一次
    Date           : 2026-08-07
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void CurrentLimit_1ms(void)
{
    uint16 limitDutyRef;

    #if (CurLimit_Enable == 1)
    if (mcState == mcRun)
    {
        I_Limt_Flag = (Power_Currt1 >= I_LimtValue_Out) ? 1 : 0;
        limitDutyRef = CurrentLimitStep(Power_Currt1, I_LimtValue_Out,
                                        Limit_DutyRef, MIN_BLDC_Duty,
                                        MAX_BLDC_Duty, 1);
    }
    else
    {
        I_Limt_Flag = 0;
        limitDutyRef = MAX_BLDC_Duty;
    }
    #else
    I_Limt_Flag = 0;
    limitDutyRef = MAX_BLDC_Duty;
    #endif

    CurrentLimitSetDutyRef(limitDutyRef);
}




/* -------------------------------------------------------------------------------------------------
    Function Name  : Duty_Function
    Description    : 占空比处理
    Date           : 2021-8-7
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Duty_Function(void)
{
    if (mcState == mcBLDC)
    {
        if (BLDC_HALL.COM_COUNT == 1)
        {
            DRV_DR = StartDuty.Duty0;
        }
        else if (BLDC_HALL.COM_COUNT == 2)
        {
            DRV_DR = StartDuty.Duty1;
        }
        else if (BLDC_HALL.COM_COUNT == 3)
        {
            DRV_DR = StartDuty.Duty2;
        }
        else if (BLDC_HALL.COM_COUNT == 4)
        {
            DRV_DR = StartDuty.Duty3;
        }

        /* 保留原来的递增方式，只替换启动上限 */
        if (DRV_DR < StartDuty.Max)
        {
            mcSpeedRamp.Motor_Duty_ADD_Cnt++;

            if (mcSpeedRamp.Motor_Duty_ADD_Cnt >
                DUTY_Updata_ADD_Num)
            {
                mcSpeedRamp.Motor_Duty_ADD_Cnt = 0;
                DRV_DR = DRV_DR + 1;
            }
        }
    }
    else if(mcState == mcRun)
				{
						if(DRV_DR < BLDC_Duty_LEVEL)        			   /*占空比低于BLDC_Duty_LEVEL，快加速*/               
						{								
								if( mcSpeedRamp.BLDC_Value > (DRV_DR + 6) )
								{
										mcSpeedRamp.Motor_Duty_ADD_Cnt++;
										mcSpeedRamp.Motor_Duty_SUB_Cnt=0;          
										if ( mcSpeedRamp.Motor_Duty_ADD_Cnt > DUTY_Updata_ADD_Num)
										{
												mcSpeedRamp.Motor_Duty_ADD_Cnt = 0;
												DRV_DR = DRV_DR + 6;
										}
								}
								else if( mcSpeedRamp.BLDC_Value < (DRV_DR - 1) )
								{
										mcSpeedRamp.Motor_Duty_ADD_Cnt=0;
										mcSpeedRamp.Motor_Duty_SUB_Cnt++;        
										if ( mcSpeedRamp.Motor_Duty_SUB_Cnt > DUTY_Updata_SUB_Num )
										{
												mcSpeedRamp.Motor_Duty_SUB_Cnt = 0;
												DRV_DR = DRV_DR - 1;
												
										}
								}
								else
								{
										 mcSpeedRamp.Motor_Duty_ADD_Cnt=0;
										 mcSpeedRamp.Motor_Duty_SUB_Cnt=0;
										 DRV_DR =  mcSpeedRamp.BLDC_Value;
								}
						}
						else                                         /*占空比高于BLDC_Duty_LEVEL，慢加速*/
						{
							if( mcSpeedRamp.BLDC_Value > (DRV_DR + 1) )      
								{
										mcSpeedRamp.Motor_Duty_ADD_Cnt++;
										mcSpeedRamp.Motor_Duty_SUB_Cnt=0;          
										if ( mcSpeedRamp.Motor_Duty_ADD_Cnt > DUTY_Updata_ADD_Num_high)
										{
												mcSpeedRamp.Motor_Duty_ADD_Cnt = 0;
												DRV_DR = DRV_DR + 1;
										}
								}
								else if( mcSpeedRamp.BLDC_Value < (DRV_DR - 1) )
								{
										mcSpeedRamp.Motor_Duty_ADD_Cnt=0;
										mcSpeedRamp.Motor_Duty_SUB_Cnt++;        
										if ( mcSpeedRamp.Motor_Duty_SUB_Cnt > DUTY_Updata_SUB_Num_high )
										{
												mcSpeedRamp.Motor_Duty_SUB_Cnt = 0;
												DRV_DR = DRV_DR - 1;
										}
								}
								else
								{
										 mcSpeedRamp.Motor_Duty_ADD_Cnt=0;
										 mcSpeedRamp.Motor_Duty_SUB_Cnt=0;
										 DRV_DR =  mcSpeedRamp.BLDC_Value;
							}
				  }
    }

    #if (CurLimit_Enable == 1)
    if ((mcState == mcRun) && (DRV_DR > Limit_DutyRef))
    {
        DRV_DR = Limit_DutyRef;
    }
    #endif
}





/*

以电转速进行计算

6MHz  最低计算的电转速为915eRPM           对应计数值65535
      电动工具最高转速一般在60000eRPM

PWM_COUNT计数值计算电机转速，将下限人为定义到100RPM

(PWM_FREQUENCY_BLDC * 10000 / eRPM )            eRPM = Pole_Pairs * RPM
载波频率     RPM      Pole_Pairs      eRPM             PWM_COUNT           TIM1时钟           BCCR         
20KHz        100          2            200               1000              6MHz               溢出
20KHz        1000         2            2000              100               6MHz               30000
20KHz        2000         2            4000              50                6MHz               15000

18KHz        100          2            200               900               6MHz               溢出
18KHz        2000         2            4000              45                6MHz               15000

*/
void PWMCount_LPF( void )
{
   static uint16 count = 0;
    
   count = BLDC_HALL.PWM_COUNT;
    
   if( count >  PWM_COUNT_MAX)     count = PWM_COUNT_MAX;
       
   if( BLDC_HALL.First_Step == 1)
   {
        BLDC_HALL.PWM_COUNT_SUM = count<<2;
        BLDC_HALL.First_Step = 0;
   }
   else
   {   
        BLDC_HALL.PWM_COUNT_SUM += count;
   }
   
   BLDC_HALL.PWM_COUNT_LPF  = BLDC_HALL.PWM_COUNT_SUM >> 2;
   BLDC_HALL.PWM_COUNT_SUM -= BLDC_HALL.PWM_COUNT_LPF;
}





/* 获取hall状态，根据HallMode不同，获得的状态也不同 */
unsigned char Get_Hall_Status(void)
{
        unsigned char HallStatus = 0;
	    unsigned char ha = 0;
		unsigned char hb = 0;
		unsigned char hc = 0;
	
	  ha = GP02;
	  hb = GP37;
	  hc = GP36;	
	
    HallStatus = ((((unsigned char)hc) << 2) | (((unsigned char)hb) << 1) | ((unsigned char)ha));
       
    return HallStatus;
}





void StarRampDealwith(void)
{
      	   		
		uint8 ANGLE_MTemp, ANGLE_DTemp;

    if (mcState == mcRun)
    {
			
        /*屏蔽续流时间（角度）设置*/
			
			
        ANGLE_MTemp = (uint8)(TIM1_CR1 & 0x7F); //读取当前的续流屏蔽和延迟换相
        ANGLE_DTemp = (uint8)(TIM1_CR2 & 0x7F);

        if (ANGLE_MASK_R(MaskAngle) > ANGLE_MTemp) //如果目标的续流屏蔽角度 > 当前续流屏蔽角度
        {
            TIM1_CR1 = (TIM1_CR1 & (0x80)) | (ANGLE_MTemp + 1); //当前续流屏蔽角度+1
        }
        else if (ANGLE_MASK_R(MaskAngle) < ANGLE_MTemp) //如果目标的续流屏蔽角度 < 当前续流屏蔽角度
        {
            TIM1_CR1 = (TIM1_CR1 & (0x80)) | (ANGLE_MTemp - 1); //当前续流屏蔽角度-1
        }
				
				
				/*延迟换相角度设置*/
    

				if (ANGLE_DELAY_R(Delay_Angle) > ANGLE_DTemp)
				{
						TIM1_CR2 = (TIM1_CR2 & (0x80)) | (ANGLE_DTemp + 1);
				}
				else if (ANGLE_DELAY_R(Delay_Angle)  < ANGLE_DTemp)
				{
						TIM1_CR2 = (TIM1_CR2 & (0x80)) | (ANGLE_DTemp - 1);
				}
        Advance_AngleDely_Data = Motor_HIGH_Advance_AngleDely;
		}
}




void SPEED_Range_Determine(void)
{


}


void FE_FUNCTION(void)
{

}




/* -------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------- */
void Delay_12us(void)
{
 unsigned char a,b;
    
 for(b=2; b>0; b--)
 for(a=2; a>0; a--);    //最后一个for循环别忘记有分号

        
}
/* -------------------------------------------------------------------------------------------------
    Function Name  : TouchOnOffMode
    Description    : 按键开关处理
    Date           : 2023-3-27
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void  TouchOnOffMode(void)
{
	if(GP00 == 0) 
    {		
        KeyCount_Up = 0;						
        if(KeyCount_Dw < 500)      //按下按键滤波（长按500ms启停）
        {
           KeyCount_Dw++;	            					
        }
        else
        {
           KeyDwFlag = 1;          //按下标志置1
           KeyCount_Dw = 0;
					 if((mcSpeedRamp.FlagONOFF==0) && (KeyReady == 1) )           //开机
					 {
							mcSpeedRamp.FlagONOFF = 1;             
              KeyReady = 0;		
              SpeedLevel = 1 ;	
							TempMinCnt = 3000;
							TempMinPhase = 0;						 
					 }
					 else if((mcSpeedRamp.FlagONOFF == 1) && (KeyReady == 1))     //停机
					 {
							GP01 = 1;
							GP02 = 1;
						  GP03 = 1;
							mcSpeedRamp.FlagONOFF = 0;
						  KeyReady = 0;
						  KeyDwFlag_SW = 0;
					 }								
        }
    }		
    else if(GP00 == 1)
    {
        KeyCount_Dw = 0;			
        if(KeyCount_Up < 15)        //弹起按键滤波
        {
            KeyCount_Up++;	
        }
        else
        {										  
            if(KeyDwFlag == 1)      //确认前面有按下
            {
                KeyDwFlag = 0;
							  KeyReady = 1;       //按键完成一次动作(按下+弹起)							  			
            }
            KeyCount_Up = 0;		
        }
    }
}
/* -------------------------------------------------------------------------------------------------
    Function Name  : SpeedSwicth
    Description    : 速度挡位切换处理
    Date           : 2023-3-27
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void  SpeedSwicth(void)
{
	if((mcSpeedRamp.FlagONOFF == 1) )
	{		
		if((GP00 == 0)&&(KeyReady == 1)) 
    {		
        KeyCount_Up_SW = 0;						
        if(KeyCount_Dw_SW < 15)           //按下按键滤波
        {
            KeyCount_Dw_SW++;								
        }
        else
        {					  
            KeyDwFlag_SW = 1;             //按下标志置1
            KeyCount_Dw_SW = 0;
        }
    }		
    else if(GP00 == 1) 
    {
        KeyCount_Dw_SW = 0;			
        if(KeyCount_Up_SW < 15)           //弹起按键滤波
        {
            KeyCount_Up_SW++;	
        }
        else
        {
            if(KeyDwFlag_SW == 1)         //确认前面有按下
            {							  
                KeyDwFlag_SW = 0;
							  if(SpeedLevel == 3)       //速度挡位切换
								{
									SpeedLevel = 1 ;
								}
								else
								{
									SpeedLevel++ ;
								}							                
            }
            KeyCount_Up_SW = 0;		
        }
    }
		
		switch(SpeedLevel)                    //挡位切换 + LED处理
		{
			case(1):
				GP01 = 0;
			  GP02 = 1;
			  GP03 = 1;
			  PID_Speed.exp= _1_Gear_Speed;     //速度环期望转速赋值_低挡  
			break;
			
			case(2):
				GP01 = 1;
			  GP02 = 0;
			  GP03 = 1;
//			  PID_Speed.exp= _2_Gear_Speed;     //速度环期望转速赋值_中挡  
			break;
			
			case(3):
				GP01 = 1;
			  GP02 = 1;
			  GP03 = 0;
//			  PID_Speed.exp= _3_Gear_Speed;     //速度环期望转速赋值_高挡  
			break;
		}
	}
}

void ON_OFF_Exchange(void)
{
    
//    [4:3]  SAMSEL   CMP0、CMP1、CMP2 和ADC 在PWM ON/OFF 采样延迟使能
//                    00-在ON 和OFF 均采样，无延迟采样
//                    01-只在OFF 采样，根据CMP_SAMR 延迟采样
//                    10-只在ON 采样，根据CMP_SAMR 延迟采样
//                    11-在ON 和OFF 均采样，根据CMP_SAMR 延迟采样
   

        if( (DRV_DR >=  OFF_TO_ON_Duty) && (BLDC_HALL.ON_OFF_FLAG == 0)  )
        {
            /*更改为ON采样*/
            SetBit(CMP_CR3 , SAMSEL1);	
            ClrBit(CMP_CR3 , SAMSEL0);	
            BLDC_HALL.ON_OFF_FLAG = 1;
        }
        else if ( (DRV_DR <= OFF_TO_ON_Duty) && (BLDC_HALL.ON_OFF_FLAG == 1))
        {
            /*更改为OFF采样*/
            ClrBit(CMP_CR3 , SAMSEL1);	
            SetBit(CMP_CR3 , SAMSEL0);	
            BLDC_HALL.ON_OFF_FLAG = 0;
        }

}

