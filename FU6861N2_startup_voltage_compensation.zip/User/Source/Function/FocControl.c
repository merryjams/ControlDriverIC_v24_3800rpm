/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
    File Name          : FocControl.c
    Author             : Fortiortech  Appliction Team
    Version            : V1.0
    Date               : 2017-12-26
    Description        : This file contains all the foc control framework used for Motor Control.
***************************************************************************************************
    All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <FocControl.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ----------------------------------------------------------------------------*/
MotStaType mcState;
MotStaM    McStaSet;
//uint16 watchtemp = 0;



/* -------------------------------------------------------------------------------------------------
    Function Name  : MC_Control
    Description    : 状态机函数
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void MC_Control(void)
{
    switch (mcState)
    {
        case mcReady:
        {
            Motor_Ready();

            if ( mcSpeedRamp.FlagONOFF == 1){
                mcState = mcInit;
            }
        }
        break;
        
        case mcInit:                                                                // 初始化
        {
            MOE      = 0;
            Motor_Init();
            mcState                 =   mcCharge;
            
        }
        break;
        
        case mcTailWind:                                                            // 顺风启动逻辑
        {
            Motor_TailWind();
        }
        break;
        
        case mcCharge:                                                              // 预充电
        {
            Motor_Charge();
            #if (IPMState == NormalRun)
            {
                if ( mcFocCtrl.State_Count == 0)
                {
                    DRV_CMR = 0;
                    DRV_DR  = 0;
                    MOE     = 0;
                    /* 先计算完整参数，再进入载波中断的启动分支 */
                    if (StartDuty_Prepare() != 0)
                    {
                        mcSpeedRamp.Motor_Duty_ADD_Cnt = 0;
                        mcFocCtrl.State_Count = 0;
                        mcState = mcBLDC;
                    }
                }
            }
            #endif
        }
        break;
        case mcBLDC:                                                                // 软件运行状态
        {
					  Motor_Start(); 
            if (mcSpeedRamp.FlagONOFF == 0)
            {
                MOE      = 0;
                TIM1_CR0 = 0;
                TIM1_CR1 = 0;
                TIM1_CR2 = 0;
                TIM1_CR3 = 0;
                TIM1_CR4 = 7;
                TIM1_IER = 0;
                FOC_CR1    = 0x00;
                DRV_DR     = 0;    //清零比较值
                ONOFFTest.StopFlag = 1;
                Driver_Init();
                ClrBit(DRV_CR, FOCEN); /*关闭FOC*/     
                mcState  = mcStop;
            }
        }
        break;
        
        case mcRun:                                                                // 软件运行状态
        {
            if (mcSpeedRamp.FlagONOFF == 0)
            {
                MOE      = 0;
                TIM1_CR0 = 0;
                TIM1_CR1 = 0;
                TIM1_CR2 = 0;
                TIM1_CR3 = 0;
                TIM1_CR4 = 7;
                TIM1_IER = 0;
                FOC_CR1    = 0x00;
                DRV_DR     = 0;    //清零比较值
                ONOFFTest.StopFlag = 1;
                Driver_Init();
                ClrBit(DRV_CR, FOCEN); /*关闭FOC*/     
                mcState  = mcStop;
            }
        }
        break;       
        
                 
        case mcStop:                                                                    // 停止状态
        {
						if (ONOFFTest.StopFlag == 1)
						{
								MOE = 0;
								DRV_DR   = (DRV_ARR);
								DRV_CMR &= 0xFFC0;
								DRV_CMR |= 0x015; //UVW下桥臂使能
//							  DRV_CMR |= 0x02A; //UVW上桥臂使能
								ClrBit(DRV_CR,OCS);
								MOE = 1;								
								mcFocCtrl.State_Count = 50;
							 ONOFFTest.StopFlag = 0;
							 ONOFFTest.BrakeTimerFlag = 1;
						}
						if(ONOFFTest.BrakeTimerFlag==1){
//           		if (mcFocCtrl.State_Count > 48)
//							{
									// 0~15ms
									// 100% duty 下桥臂刹车
									DRV_DR = DRV_ARR;
//							}
//							else if (mcFocCtrl.State_Count > 30)
//							{
//									// 15~30ms
//									// 90% duty 下桥臂刹车
//									DRV_DR = (DRV_ARR * 8) / 10;
//							}
//							else
//							{
//									// 30~50ms
//									// 50% duty 下桥臂刹车
//									DRV_DR = DRV_ARR / 2;
//							} 									
						}							
            if (( (mcFaultSource == FaultNoSource) ||((mcFaultSource != FaultNoSource) && (mcSpeedRamp.FlagONOFF == 0)) )&&(mcFocCtrl.State_Count == 0))               
            {
                /*保护函数变量清零*/
                mcFaultDect.OverCurrentCnt    = 0;
                mcFaultDect.OverCurrentCnt1   = 0;
                mcFaultDect.OverCurrentCnt2   = 0;
                mcState  = mcBrake; 
								ONOFFTest.BrakeTimerFlag = 0;							
            }
        }
        break;
        
        case mcBrake:                                                                   // 刹车
        {
                MOE      = 0;
                DRV_DR     = 0;    //刹车力度
								DRV_CMR  = UVW_OFF;					
					//sc_goToSleep();  //休眠
            if (mcSpeedRamp.FlagONOFF == 1)
            {               
                mcState = mcReady;
							  SleepSet.SleepDelayCout = 0;
							  SleepSet.SleepFlag =0;
                MOE      = 0;
                DRV_CMR  = UVW_OFF;
            }
        }
        break;
        
        case mcFault:                                                                   // 错误状态
        {
          if(mcFaultSource == FaultNoSource)  mcState = mcStop;
					
					if((mcFaultSource == FaultSoftOVCurrent) ||(mcFaultSource == FaultSoftOVCurrent1) ||(mcFaultSource == FaultSoftOVCurrent2)||(mcFaultSource == FaultHardOVCurrent))
          {  
					   ONOFFTest.StopFlag = 0;        //发生过流保护以后   刹车: 1  ; 不刹车: 0
					}
					else
				  {  
					   ONOFFTest.StopFlag = 0;        //发生保护以后不刹车   刹车: 1  ; 不刹车: 0
					}
        }
        break;
    }
}


