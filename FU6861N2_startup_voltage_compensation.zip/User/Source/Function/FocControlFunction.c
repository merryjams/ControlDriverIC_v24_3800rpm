/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
    File Name          : FocControl.c
    Author             : Fortiortech  Appliction Team
    Version            : V1.0
    Date               : 10-Apr-2017
    Description        : This file contains all the foc control function used for motor control.
***************************************************************************************************
    All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>
#include <FU68xx_2_DMA.h>

CurrentOffset xdata mcCurOffset;


/* -------------------------------------------------------------------------------------------------
    Function Name  : Motor_Charge
    Description    : 预充电，当一直处于预充电状态下，不接电机，可用于验证IPM或者Mos。预充电分三步，
    第一步是对U相进行预充电，第二步是对V相进行预充电;第三步是对W相进行预充电。
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Charge(void)
{
    if (McStaSet.SetFlag.ChargeSetFlag == 0)
    {
        McStaSet.SetFlag.ChargeSetFlag = 1;
				mcFocCtrl.State_Count = Charge_Time;
        #if (IPMState == IPMtest)                                        // 三相测试
        {
            DRV_DR = 0.2 * DRV_ARR;
        }
        #elif (IPMState == NormalRun)                                    // 正常运行
        {
            DRV_DR = Charge_Duty * DRV_ARR;
        }
        #endif
        mcFocCtrl.ChargeStep = 0;
        /*  -------------------------------------------------------------------------------------------------
        DRV_CTL：PWM来源选择
        OCS = 0, DRV_COMR
        OCS = 1, FOC/SVPWM/SPWM
        -------------------------------------------------------------------------------------------------*/
        ClrBit(DRV_CR, OCS);
    }
    
    if (mcFocCtrl.State_Count < Charge_Time)
    {
        #if (IPMState == IPMtest)
        {
            DRV_CMR |= 0x003f;                                                               // 三相输出
        }
        #elif (IPMState == NormalRun)                                                        // 正常按电机状态机运行
        {
            
//            DRV_CMR = ULVLWL_ON;
            if ( (mcFocCtrl.State_Count < Charge_Time) && (mcFocCtrl.ChargeStep == 0))
            {
                DRV_CMR = UL_ON;
                mcFocCtrl.ChargeStep = 1;
            }
            else if ((mcFocCtrl.State_Count <  (Charge_Time << 1) / 3) && (mcFocCtrl.ChargeStep == 1) )
            {
                DRV_CMR = VL_ON;
                mcFocCtrl.ChargeStep = 2;
            }
            else if ((mcFocCtrl.State_Count <  (Charge_Time  / 3) ) && (mcFocCtrl.ChargeStep == 2) )
            {
                DRV_CMR = WL_ON;
                mcFocCtrl.ChargeStep = 3;
            }
        }
        #endif
        MOE = 1;
    }
}





/* -------------------------------------------------------------------------------------------------
    Function Name  : Motor_TailWind
    Description    : 顺风启动初始化
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_TailWind(void)
{
    if (McStaSet.SetFlag.TailWindSetFlag == 0)
    {
        if ( mcFRState.TargetFR == CW )
        {
            ClrBit(DRV_CR, DDIR);                              // 正转
        }
        else if ( mcFRState.TargetFR == CCW )
        {
            SetBit(DRV_CR, DDIR);                              // 反转
        }
        
        CMP_BEMF_Init();
        TIM2_TailWind_Init();
        McStaSet.SetFlag.TailWindSetFlag = 1;
    }
}





/* -------------------------------------------------------------------------------------------------
    Function Name  : Motor_Start
    Description    : XX-XX-XX
    Date           : 2023-05-08
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Start(void)
{
	 if (McStaSet.SetFlag.StartSetFlag == 0)
    {
        McStaSet.SetFlag.StartSetFlag = 1;
        
        /**********电机目标方向*************/
        if (mcFRState.TargetFR == CW)
        {           
            ClrBit(DRV_CR , DDIR);
        }
        else
        {            
            SetBit(DRV_CR , DDIR);
        }
        
        /* -----电流偏置校准变量初始化----- */
        CMP012_Init();
        MotorStart(1);
        DRV_DR = StartDuty.Init;
        BLDC_HALL.First_Step    = 1;
        MOE                     = 1;
        BLDC_HALL.BDIF_Flag     = 1;
				//GP12=1;  //TEST
    }
	
}




/* -------------------------------------------------------------------------------------------------
    Function Name  : MotorcontrolInit
    Description    : 电机控制变量初始化
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void MotorcontrolInit(void)
{
    memset(&mcFaultDect, 0, sizeof(FaultVarible));
    memset(&ONOFFTest, 0, sizeof(ONVarible));
    McStaSet.SetMode                   = 0;
    mcFRState.TargetFR                 = 0;
    memset(&mcFocCtrl, 0, sizeof(FOCCTRL));
    memset(&mcCurOffset, 0, sizeof(CurrentOffset));                         //电流采样相关设置
    mcCurOffset.IuOffsetSum            = 16383;
    mcCurOffset.IvOffsetSum            = 16383;
    mcCurOffset.Iw_busOffsetSum        = 16383;
    mcCurOffset.IbusRcOffsetSum        = 16383;
    mcCurOffset.OffsetFlag             = 0;
	
}







/* -------------------------------------------------------------------------------------------------
    Function Name  : VariablesPreInit
    Description    : 变量初始化
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void VariablesPreInit(void)
{
	
	  Loop_Ref.Loop_Time_Cnt=0; //速度环相关变量
    Loop_Ref.Loop_Delay_Cnt=0;
    Loop_Ref.Loop_Mode=0;
//    PID_Speed.act_flt=0;
	
	  memset(&mcSpeedRamp, 0, sizeof(MCRAMP));
	  memset(&PID_Speed, 0, sizeof(PID_PARA));	
    mcFaultSource = FaultNoSource;
    memset(&mcFaultDect, 0, sizeof(FaultVarible));
    memset(&mcFocCtrl, 0, sizeof(FOCCTRL));
    memset(&Tailwind, 0, sizeof(TailWind_TypeDef));
    memset(&BLDC_HALL, 0, sizeof(BLDC_HALL_PARA));
//    memset(&IPD, 0, sizeof(IPD_TypeDef));
	  memset(&SleepSet, 0, sizeof(SLEEPMODE));
    McStaSet.SetMode  = 0;
    
    memset(&mcLedDisplay, 0, sizeof(MCLedDisplay));                                             // mcLedDisplay变量清零
    
	
		TempMinCnt = 3000;
		TempMinPhase = 0;
    
}






/* -------------------------------------------------------------------------------------------------
    Function Name  : GetCurrentOffset
    Description    : 电流采样偏执电压提取
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void GetCurrentOffset(void)
{
    SetBit(ADC_CR, ADCBSY);                                  // 使能ADC
    
    while (ReadBit(ADC_CR, ADCBSY));
    
    mcCurOffset.Iw_busOffsetSum += ((ADC4_DR & 0x0fff) << 3);
    mcCurOffset.Iw_busOffset = mcCurOffset.Iw_busOffsetSum >> 4;
    mcCurOffset.Iw_busOffsetSum -= mcCurOffset.Iw_busOffset;

    mcCurOffset.IbusRcOffsetSum += ((ADC11_DR & 0x0fff) << 3);
    mcCurOffset.IbusRcOffset = mcCurOffset.IbusRcOffsetSum >> 4;
    mcCurOffset.IbusRcOffsetSum -= mcCurOffset.IbusRcOffset;
    mcCurOffset.OffsetCount++;
    
    if (mcCurOffset.OffsetCount > Calib_Time)
    {
        mcCurOffset.OffsetFlag = 1;
    }
}






/* -------------------------------------------------------------------------------------------------
    Function Name  : Motor_Ready
    Description    : 电机初始化
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Ready(void)
{
}







/* -------------------------------------------------------------------------------------------------
    Function Name  : Motor_Init
    Description    : 驱动变量初始化
    Date           : 2022-02-21
    Parameter      : None
------------------------------------------------------------------------------------------------- */
void Motor_Init(void)
{ 
			
    VariablesPreInit();                                  // 电机相关变量初始化
    PI_Init();                                           // PI初始化
    BLDC_HALL.DBR[0] = ULVLWL_ON +  CMP_UVW_NO;          // 三相下桥开启 刹车
    BLDC_HALL.DBR[1] = UH_VLA1   +  CMP_W_DO;            // 5  UH_VL
    BLDC_HALL.DBR[2] = UH_WLA1   +  CMP_V_UP;            // 1  UH_WL
    BLDC_HALL.DBR[3] = VH_WLA1   +  CMP_U_DO;            // 3  VH_WL
    BLDC_HALL.DBR[4] = VH_ULA1   +  CMP_W_UP;            // 2  VH_UL
    BLDC_HALL.DBR[5] = WH_ULA1   +  CMP_V_DO;            // 6  WH_UL
    BLDC_HALL.DBR[6] = WH_VLA1   +  CMP_U_UP;            // 4  WH_VL
    BLDC_HALL.DBR[7] = UVW_OFF   +  CMP_UVW_NO;          // 三相全关

//    BLDC_SET();
    if(FRDirect ==1) mcFRState.TargetFR = CW;
	  else mcFRState.TargetFR = CCW;
    //mcFRState.TargetFR = FRMODE;
                            //转向设置

}


